/*
 * hello_motor.cpp — Build this file yourself, step by step.
 *
 * GOAL: Send one position command to one motor and print what it reports back.
 *
 * Build when ready:
 *   g++ -std=c++17 -I../include -o hello_motor hello_motor.cpp
 *
 * Run:
 *   sudo ./hello_motor <motor_id> <degrees>
 *   e.g.  sudo ./hello_motor 11 45
 *
 * ============================================================
 *  WHAT YOU NEED TO KNOW BEFORE WRITING ANY CODE
 * ============================================================
 *
 *  1. CAN ID LAYOUT (29-bit extended)
 *     Each message has a 29-bit ID that carries meaning:
 *
 *       bits [28:24]  comm_type   — what command? (5 bits)
 *       bits [23:16]  extra       — depends on command
 *       bits [15:8]   sender_id   — who is sending  (PC = 0xFF)
 *       bits [7:0]    motor_id    — who should act
 *
 *     Example — ENABLE (type=3) to motor 11:
 *       ext_id = (3 << 24) | (0 << 16) | (0xFF << 8) | 11
 *
 *  2. COMM TYPES (from protocol_completed.h → CommType namespace)
 *     ENABLE           = 3    no data, wakes motor
 *     DISABLE          = 4    no data, idles motor
 *     WRITE_PARAMETER  = 18   8 bytes: [param_id LE 2B][padding 2B][value 4B]
 *     OPERATION_CONTROL= 1    8 bytes: position/vel/kp/kd packed as uint16 BE
 *                             torque_ff goes in CAN ID bits [23:8]
 *     OPERATION_STATUS = 2    reply FROM motor: pos/vel/torque/temp/fault
 *
 *  3. PARAMETER IDS (from protocol_completed.h → ParamID namespace)
 *     ParamID::MODE     = 0x7005   int8:  0=MIT, 1=Position, 2=Speed, 3=Torque
 *     ParamID::VELOCITY_LIMIT = 0x7017  float: rad/s
 *     ParamID::TORQUE_LIMIT   = 0x700B  float: Nm
 *
 *  4. SCALE TABLES (from protocol_completed.h → ModelScale::RS03)
 *     POSITION = 4π  rad      signed ±
 *     VELOCITY = 50  rad/s    signed ±
 *     TORQUE   = 60  Nm       signed ±
 *     KP       = 5000 Nm/rad  unsigned 0–max
 *     KD       = 100  Nm·s/rad unsigned 0–max
 *
 *  5. ENCODING FORMULAS
 *     Signed value  (pos, vel, torque):
 *       raw_u16 = (value / max + 1.0) * 32767      range → [0, 65534]
 *       0 maps to 32767 (midpoint)
 *
 *     Unsigned value (kp, kd):
 *       raw_u16 = (value / max) * 65535             range → [0, 65535]
 *
 *     DECODING (what motor replies):
 *       value = (raw_u16 / 32767.0 - 1.0) * max
 *
 *  6. BYTE ORDER
 *     Control frame data bytes   → BIG-endian    (use pack_u16_be)
 *     WRITE_PARAMETER param_id   → LITTLE-endian (use pack_u16_le)
 *     WRITE_PARAMETER float val  → LITTLE-endian (use pack_float_le / memcpy)
 *
 *  7. USEFUL API FROM can_interfaces.h
 *     CanInterface can;
 *     can.init("can0");                            // open the socket
 *     can.write_frame(ext_id, data, dlc);          // send a frame
 *     can.read_frame(&frame, timeout_ms);          // receive a frame (returns bool)
 *     can.is_ready();                              // check if socket open
 *
 *     The received frame is a Linux struct can_frame:
 *       frame.can_id   — full 29-bit ID with CAN_EFF_FLAG set
 *       frame.can_dlc  — number of data bytes
 *       frame.data[]   — up to 8 payload bytes
 *
 *     To extract fields from a received can_id:
 *       uint32_t comm_type = (frame.can_id >> 24) & 0x1F;
 *       int      src_id    = (frame.can_id >>  8) & 0xFF;
 *
 * ============================================================
 *  YOUR TASKS — fill in each section below
 * ============================================================
 */

#include "../include/motor_control.hpp"
#include <cctype>
#include <cmath>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <chrono>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <map>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <atomic>
#include <memory>
#include <iomanip>
#include <sched.h>
#include <sys/mman.h>
#include <pthread.h>
// torque — motor can be rotated freely by hand.

// CLI: <cmd> <target_deg> <id> <type> [<id> <type> ...]
//
//  z               — zero ALL listed motors
//  zp <motor_id>   — zero ONE motor (put its id as target_deg, list all motors)
//  r               — passive read all (zero torque)
//  w               — move+read all to target_deg
//  t <torque>     — apply torque to all motors and read status
//  s               — move through multiple target angles and hold each one
struct SequenceStep
{
    double angle_deg = 0.0;
    double kp = 1.0;
    double kd = 0.5;
    double torque_ff = 0.0;
    double velocity_deg_s = 0.0;
};

struct PlotSample
{
    double time_s = 0.0;
    double target_deg = 0.0;
    double actual_deg = 0.0;
    double observed_hz = 0.0;
    double target_vel_deg_s = 0.0;
    double actual_vel_deg_s = 0.0;
    double actual_torque = 0.0;
};

class RealtimeGnuplot
{
public:
    explicit RealtimeGnuplot(const std::vector<Motor> &motors)
    {
        if (std::system("command -v gnuplot >/dev/null 2>&1") != 0)
        {
            std::cerr << "Warning: gnuplot is not installed. CSV logging will continue.\n";
            return;
        }

        for (const auto &m : motors)
            samples_[m.id] = {};

        // Open four separate gnuplot windows — one per plot type
        pipe_angle_ = popen("gnuplot -persist", "w");
        pipe_freq_  = popen("gnuplot -persist", "w");
        pipe_vel_   = popen("gnuplot -persist", "w");
        pipe_accel_ = popen("gnuplot -persist", "w");
        pipe_inertia_ = popen("gnuplot -persist", "w");

        if (pipe_angle_)
        {
            std::fprintf(pipe_angle_, "set term qt size 900,400 title 'Position vs Time'\n");
            std::fprintf(pipe_angle_, "set title 'Angle sequence tracking'\n");
            std::fprintf(pipe_angle_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_angle_, "set ylabel 'Angle (deg)'\n");
            std::fprintf(pipe_angle_, "set grid\n");
            std::fprintf(pipe_angle_, "set key outside bottom center horizontal\n");
            std::fflush(pipe_angle_);
        }
        if (pipe_freq_)
        {
            std::fprintf(pipe_freq_, "set term qt size 900,400 title 'Observed Loop Frequency'\n");
            std::fprintf(pipe_freq_, "set title 'Observed Loop Frequency'\n");
            std::fprintf(pipe_freq_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_freq_, "set ylabel 'Frequency (Hz)'\n");
            std::fprintf(pipe_freq_, "set grid\n");
            std::fprintf(pipe_freq_, "set key outside bottom center horizontal\n");
            std::fflush(pipe_freq_);
        }
        if (pipe_vel_)
        {
            std::fprintf(pipe_vel_, "set term qt size 900,400 title 'Velocity vs Time'\n");
            std::fprintf(pipe_vel_, "set title 'Velocity over time'\n");
            std::fprintf(pipe_vel_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_vel_, "set ylabel 'Velocity (deg/s)'\n");
            std::fprintf(pipe_vel_, "set grid\n");
            std::fprintf(pipe_vel_, "set key outside bottom center horizontal\n");
            std::fflush(pipe_vel_);
        }
        if (pipe_accel_)
        {
            std::fprintf(pipe_accel_, "set term qt size 900,400 title 'Angular Acceleration vs Time'\n");
            std::fprintf(pipe_accel_, "set title 'Angular Acceleration (smoothed)'\n");
            std::fprintf(pipe_accel_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_accel_, "set ylabel 'Acceleration (deg/s^2)'\n");
            std::fprintf(pipe_accel_, "set grid\n");
            std::fprintf(pipe_accel_, "set key outside bottom center horizontal\n");
            std::fflush(pipe_accel_);
        }
        if (pipe_inertia_)
        {
            std::fprintf(pipe_inertia_, "set term qt size 900,400 title 'Estimated Inertia vs Time'\n");
            std::fprintf(pipe_inertia_, "set title 'Estimated Moment of Inertia (I = \u03c4 / \u03b1)'\n");
            std::fprintf(pipe_inertia_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_inertia_, "set ylabel 'Inertia (Nm/(rad/s^2))'\n");
            std::fprintf(pipe_inertia_, "set grid\n");
            std::fprintf(pipe_inertia_, "set key outside bottom center horizontal\n");
            std::fflush(pipe_inertia_);
        }
    }

    ~RealtimeGnuplot()
    {
        if (pipe_angle_) pclose(pipe_angle_);
        if (pipe_freq_)  pclose(pipe_freq_);
        if (pipe_vel_)   pclose(pipe_vel_);
        if (pipe_accel_) pclose(pipe_accel_);
        if (pipe_inertia_) pclose(pipe_inertia_);
    }

    bool ready() const
    {
        return pipe_angle_ != nullptr;
    }

    void add_sample(int motor_id, double time_s, double target_deg, double actual_deg, double observed_hz,
                    double target_vel_deg_s = 0.0, double actual_vel_deg_s = 0.0, double actual_torque = 0.0)
    {
        samples_[motor_id].push_back({time_s, target_deg, actual_deg, observed_hz, target_vel_deg_s, actual_vel_deg_s, actual_torque});
    }

    void write_data_files() const
    {
        static const int SMOOTH_WINDOW = 100; // 100-sample (100ms) moving average for clean acceleration

        for (const auto &entry : samples_)
        {
            std::ostringstream path;
            path << "/tmp/robstride_plot_" << entry.first << ".dat";
            std::ofstream ofs(path.str(), std::ios::trunc);
            if (!ofs)
                continue;

            const auto &vec = entry.second;

            // First pass: compute raw acceleration for every sample
            std::vector<double> raw_accel(vec.size(), 0.0);
            for (size_t i = 1; i < vec.size(); i++)
            {
                double dt = vec[i].time_s - vec[i - 1].time_s;
                if (dt > 1e-9)
                    raw_accel[i] = (vec[i].actual_vel_deg_s - vec[i - 1].actual_vel_deg_s) / dt;
            }

            // Second pass: moving average smoothing + inertia
            double sum_x = 0.0, sum_y = 0.0, sum_xx = 0.0, sum_xy = 0.0;
            int n_regression = 0;

            for (size_t i = 0; i < vec.size(); i++)
            {
                const auto &sample = vec[i];

                // Smoothed acceleration (centred window, clamped at edges)
                double sum = 0.0;
                int count = 0;
                int half = SMOOTH_WINDOW / 2;
                for (int j = -(half); j <= half; j++)
                {
                    int idx = (int)i + j;
                    if (idx >= 0 && idx < (int)vec.size())
                    {
                        sum += raw_accel[idx];
                        count++;
                    }
                }
                double smoothed_accel = (count > 0) ? sum / count : 0.0;

                // Convert to rad/s^2 for inertia calculation
                double accel_rad_s2 = smoothed_accel * M_PI / 180.0;

                // Inertia: I = τ / α  (Nm / (rad/s^2) = kg·m²)
                // Only meaningful when acceleration is significant
                double inertia = 0.0;
                if (std::fabs(accel_rad_s2) > 0.5)  // threshold to avoid division by tiny values
                {
                    inertia = sample.actual_torque / accel_rad_s2;
                    // Cap inertia to prevent massive spikes on the plot when accel is near zero
                    if (inertia > 5.0) inertia = 5.0;
                    if (inertia < -5.0) inertia = -5.0;
                }

                // Columns: 1=time 2=actual_deg 3=target_deg 4=freq 5=vel_actual 6=vel_target 7=smoothed_accel 8=inertia
                ofs << sample.time_s << " "
                    << sample.actual_deg << " "
                    << sample.target_deg << " "
                    << sample.observed_hz << " "
                    << sample.actual_vel_deg_s << " "
                    << sample.target_vel_deg_s << " "
                    << smoothed_accel << " "
                    << inertia << "\n";

                // Accumulate data for true inertia estimation (linear regression slope)
                if (std::fabs(accel_rad_s2) > 2.0)
                {
                    sum_x += accel_rad_s2;
                    sum_y += sample.actual_torque;
                    sum_xx += accel_rad_s2 * accel_rad_s2;
                    sum_xy += accel_rad_s2 * sample.actual_torque;
                    n_regression++;
                }
            }

            if (n_regression > 1)
            {
                double denominator = (n_regression * sum_xx - sum_x * sum_x);
                if (std::fabs(denominator) > 1e-9)
                    estimated_inertias_[entry.first] = (n_regression * sum_xy - sum_x * sum_y) / denominator;
            }
        }
    }

    // Update all three windows at once
    void redraw_all()
    {
        if (samples_.empty())
            return;

        write_data_files();

        // ---- Position vs Time ----
        if (pipe_angle_)
        {
            std::fprintf(pipe_angle_, "reset\n");
            std::fprintf(pipe_angle_, "set term qt size 900,400 title 'Position vs Time'\n");
            std::fprintf(pipe_angle_, "set title 'Angle sequence tracking'\n");
            std::fprintf(pipe_angle_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_angle_, "set ylabel 'Angle (deg)'\n");
            std::fprintf(pipe_angle_, "set grid\n");
            std::fprintf(pipe_angle_, "set key outside bottom center horizontal\n");
            bool first = true;
            std::fprintf(pipe_angle_, "plot ");
            for (const auto &entry : samples_)
            {
                const auto &vec = entry.second;
                if (vec.empty()) continue;
                std::ostringstream path;
                path << "/tmp/robstride_plot_" << entry.first << ".dat";
                if (!first) std::fprintf(pipe_angle_, ", ");
                if (vec.size() == 1)
                {
                    std::fprintf(pipe_angle_, "'%s' using 1:2 with points pt 7 ps 1.5 title 'M%d actual'", path.str().c_str(), entry.first);
                    std::fprintf(pipe_angle_, ", '%s' using 1:3 with points pt 6 ps 1.5 title 'M%d target'", path.str().c_str(), entry.first);
                }
                else
                {
                    std::fprintf(pipe_angle_, "'%s' using 1:2 with lines lw 2 title 'M%d actual'", path.str().c_str(), entry.first);
                    std::fprintf(pipe_angle_, ", '%s' using 1:3 with lines dt 2 lw 2 title 'M%d target'", path.str().c_str(), entry.first);
                }
                first = false;
            }
            std::fprintf(pipe_angle_, "\n");
            std::fflush(pipe_angle_);
        }

        // ---- Observed Loop Frequency ----
        if (pipe_freq_)
        {
            std::fprintf(pipe_freq_, "reset\n");
            std::fprintf(pipe_freq_, "set term qt size 900,400 title 'Observed Loop Frequency'\n");
            std::fprintf(pipe_freq_, "set title 'Observed Loop Frequency'\n");
            std::fprintf(pipe_freq_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_freq_, "set ylabel 'Frequency (Hz)'\n");
            std::fprintf(pipe_freq_, "set grid\n");
            std::fprintf(pipe_freq_, "set key outside bottom center horizontal\n");
            bool first = true;
            std::fprintf(pipe_freq_, "plot ");
            for (const auto &entry : samples_)
            {
                const auto &vec = entry.second;
                if (vec.empty()) continue;
                std::ostringstream path;
                path << "/tmp/robstride_plot_" << entry.first << ".dat";
                if (!first) std::fprintf(pipe_freq_, ", ");
                if (vec.size() == 1)
                    std::fprintf(pipe_freq_, "'%s' using 1:4 with points pt 7 ps 1.5 title 'M%d freq'", path.str().c_str(), entry.first);
                else
                    std::fprintf(pipe_freq_, "'%s' using 1:4 with lines lw 2 title 'M%d freq'", path.str().c_str(), entry.first);
                first = false;
            }
            std::fprintf(pipe_freq_, "\n");
            std::fflush(pipe_freq_);
        }

        // ---- Velocity vs Time ----
        if (pipe_vel_)
        {
            std::fprintf(pipe_vel_, "reset\n");
            std::fprintf(pipe_vel_, "set term qt size 900,400 title 'Velocity vs Time'\n");
            std::fprintf(pipe_vel_, "set title 'Velocity over time'\n");
            std::fprintf(pipe_vel_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_vel_, "set ylabel 'Velocity (deg/s)'\n");
            std::fprintf(pipe_vel_, "set grid\n");
            std::fprintf(pipe_vel_, "set key outside bottom center horizontal\n");
            bool first = true;
            std::fprintf(pipe_vel_, "plot ");
            for (const auto &entry : samples_)
            {
                const auto &vec = entry.second;
                if (vec.empty()) continue;
                std::ostringstream path;
                path << "/tmp/robstride_plot_" << entry.first << ".dat";
                if (!first) std::fprintf(pipe_vel_, ", ");
                if (vec.size() == 1)
                {
                    std::fprintf(pipe_vel_, "'%s' using 1:5 with points pt 7 ps 1.5 title 'M%d actual'", path.str().c_str(), entry.first);
                    std::fprintf(pipe_vel_, ", '%s' using 1:6 with points pt 6 ps 1.5 title 'M%d target'", path.str().c_str(), entry.first);
                }
                else
                {
                    std::fprintf(pipe_vel_, "'%s' using 1:5 with lines lw 2 title 'M%d actual'", path.str().c_str(), entry.first);
                    std::fprintf(pipe_vel_, ", '%s' using 1:6 with lines dt 2 lw 2 title 'M%d target'", path.str().c_str(), entry.first);
                }
                first = false;
            }
            std::fprintf(pipe_vel_, "\n");
            std::fflush(pipe_vel_);
        }

        // ---- Angular Acceleration vs Time ----
        if (pipe_accel_)
        {
            std::fprintf(pipe_accel_, "reset\n");
            std::fprintf(pipe_accel_, "set term qt size 900,400 title 'Angular Acceleration vs Time'\n");
            std::fprintf(pipe_accel_, "set title 'Angular Acceleration (100-sample smoothed)'\n");
            std::fprintf(pipe_accel_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_accel_, "set ylabel 'Acceleration (deg/s^2)'\n");
            std::fprintf(pipe_accel_, "set grid\n");
            std::fprintf(pipe_accel_, "set key outside bottom center horizontal\n");
            bool first = true;
            std::fprintf(pipe_accel_, "plot ");
            for (const auto &entry : samples_)
            {
                const auto &vec = entry.second;
                if (vec.empty()) continue;
                std::ostringstream path;
                path << "/tmp/robstride_plot_" << entry.first << ".dat";
                if (!first) std::fprintf(pipe_accel_, ", ");
                if (vec.size() == 1)
                    std::fprintf(pipe_accel_, "'%s' using 1:7 with points pt 7 ps 1.5 title 'M%d accel'", path.str().c_str(), entry.first);
                else
                    std::fprintf(pipe_accel_, "'%s' using 1:7 with lines lw 2 title 'M%d accel'", path.str().c_str(), entry.first);
                first = false;
            }
            std::fprintf(pipe_accel_, "\n");
            std::fflush(pipe_accel_);
        }

        // ---- Estimated Inertia vs Time ----
        if (pipe_inertia_)
        {
            std::fprintf(pipe_inertia_, "reset\n");
            std::fprintf(pipe_inertia_, "set term qt size 900,400 title 'Estimated Inertia vs Time'\n");
            
            std::ostringstream title_str;
            title_str << "Estimated Moment of Inertia (I = tau / alpha)";
            for (const auto& kv : estimated_inertias_)
                title_str << " | M" << kv.first << ": " << std::fixed << std::setprecision(5) << kv.second << " kg m^2";
                
            std::fprintf(pipe_inertia_, "set title '%s'\n", title_str.str().c_str());
            std::fprintf(pipe_inertia_, "set xlabel 'Time (s)'\n");
            std::fprintf(pipe_inertia_, "set ylabel 'Inertia (kg m^2)'\n");
            std::fprintf(pipe_inertia_, "set grid\n");
            std::fprintf(pipe_inertia_, "set key outside bottom center horizontal\n");
            bool first = true;
            std::fprintf(pipe_inertia_, "plot ");
            for (const auto &entry : samples_)
            {
                const auto &vec = entry.second;
                if (vec.empty()) continue;
                std::ostringstream path;
                path << "/tmp/robstride_plot_" << entry.first << ".dat";
                if (!first) std::fprintf(pipe_inertia_, ", ");
                if (vec.size() == 1)
                    std::fprintf(pipe_inertia_, "'%s' using 1:8 with points pt 7 ps 1.5 title 'M%d inertia'", path.str().c_str(), entry.first);
                else
                    std::fprintf(pipe_inertia_, "'%s' using 1:8 with lines lw 2 title 'M%d inertia'", path.str().c_str(), entry.first);
                first = false;
            }
            std::fprintf(pipe_inertia_, "\n");
            std::fflush(pipe_inertia_);
        }
    }
private:
    FILE *pipe_angle_ = nullptr;
    FILE *pipe_freq_  = nullptr;
    FILE *pipe_vel_   = nullptr;
    FILE *pipe_accel_ = nullptr;
    FILE *pipe_inertia_ = nullptr;
    std::map<int, std::vector<PlotSample>> samples_;
    mutable std::map<int, double> estimated_inertias_;
};

// ---- Logging infrastructure for non-blocking I/O ----------------------------
struct LogEntry
{
    long timestamp_ms = 0;
    int motor_id = 0;
    int pos_raw = 0;
    double target_deg = 0.0;
    double target_vel_deg_s = 0.0;
    double actual_deg = 0.0;
    double error_deg = 0.0;
    double vel_deg_s = 0.0;
    double kp = 0.0;
    double kd = 0.0;
    double torque_ff = 0.0;
    double actual_torque = 0.0;
    double loop_dt_us = 0.0;
    double observed_hz = 0.0;
};

struct ConsoleLine
{
    std::string text;
};

class LoggerThread
{
public:
    explicit LoggerThread(std::ofstream &file, bool enable_console = true, 
                         RealtimeGnuplot *plotter = nullptr)
        : file_(file), enable_console_(enable_console), plotter_(plotter),
          running_(true)
    {
        thread_ = std::thread([this]() { run(); });
    }

    ~LoggerThread()
    {
        running_.store(false);
        if (thread_.joinable())
            thread_.join();
    }

    void enqueue_log(const LogEntry &entry)
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        log_queue_.push(entry);
    }

    void enqueue_console(const std::string &text)
    {
        std::lock_guard<std::mutex> lock(queue_mutex_);
        console_queue_.push({text});
    }

    void wait_for_flush()
    {
        std::unique_lock<std::mutex> idle_lock(idle_mutex_);
        idle_cv_.wait(idle_lock, [this]() {
            std::lock_guard<std::mutex> queue_lock(queue_mutex_);
            return log_queue_.empty() && console_queue_.empty() && !plotter_redraw_ && idle_;
        });
    }

    void set_plotter_redraw(int iter, int freq = 5)
    {
        if (plotter_ && (iter % freq == 0))
        {
            std::lock_guard<std::mutex> lock(queue_mutex_);
            plotter_redraw_ = true;
        }
    }

private:
    void run()
    {
        while (running_.load())
        {
            bool has_work = false;
            bool do_plot_redraw = false;
            std::vector<ConsoleLine> local_console;
            std::vector<LogEntry> local_logs;

            // Move queues into local containers while holding lock briefly
            {
                std::lock_guard<std::mutex> lock(queue_mutex_);
                while (!console_queue_.empty())
                {
                    local_console.push_back(console_queue_.front());
                    console_queue_.pop();
                }
                while (!log_queue_.empty())
                {
                    local_logs.push_back(log_queue_.front());
                    log_queue_.pop();
                }
                do_plot_redraw = plotter_redraw_;
                plotter_redraw_ = false;
            }

            // Process console messages (no mutex held)
            for (auto &msg : local_console)
            {
                if (enable_console_)
                    std::cout << msg.text;
                has_work = true;
            }

            // Process log entries (no mutex held)
            for (auto &entry : local_logs)
            {
                file_ << entry.timestamp_ms << ","
                      << entry.motor_id << ","
                      << entry.pos_raw << ","
                      << entry.target_deg << ","
                      << entry.target_vel_deg_s << ","
                      << entry.actual_deg << ","
                      << entry.error_deg << ","
                      << entry.vel_deg_s << ","
                      << entry.kp << ","
                      << entry.kd << ","
                      << entry.torque_ff << ","
                      << entry.actual_torque << ","
                      << entry.loop_dt_us << ","
                      << entry.observed_hz << "\n";
                // flush intermittently could be expensive; keep existing immediate flush
                file_.flush();

                if (plotter_)
                    plotter_->add_sample(entry.motor_id, entry.timestamp_ms / 1000.0,
                                         entry.target_deg, entry.actual_deg,
                                         entry.observed_hz, entry.target_vel_deg_s, entry.vel_deg_s,
                                         entry.actual_torque);
                has_work = true;
            }

            // Handle plotter redraw (outside lock)
            if (do_plot_redraw && plotter_)
            {
                plotter_->redraw_all();
                has_work = true;
            }

            if (!has_work)
                std::this_thread::sleep_for(std::chrono::milliseconds(1));

            {
                std::lock_guard<std::mutex> idle_lock(idle_mutex_);
                idle_ = !has_work;
            }
            idle_cv_.notify_all();
        }
    }

    std::ofstream &file_;
    bool enable_console_;
    RealtimeGnuplot *plotter_;
    std::atomic<bool> running_;
    std::mutex idle_mutex_;
    std::condition_variable idle_cv_;
    bool idle_ = true;
    std::thread thread_;
    std::mutex queue_mutex_;
    std::queue<LogEntry> log_queue_;
    std::queue<ConsoleLine> console_queue_;
    bool plotter_redraw_ = false;
};

void enable_realtime()
{
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0)
        perror("mlockall");

    struct sched_param param;
    param.sched_priority = 90;
    if (sched_setscheduler(0, SCHED_FIFO, &param) != 0)
        perror("sched_setscheduler");

    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(0, &cpuset);
    if (sched_setaffinity(0, sizeof(cpuset), &cpuset) != 0)
        perror("sched_setaffinity");
}

static bool is_motor_type(const std::string &value)
{
    return value == "rs00" || value == "rs01" || value == "rs02" ||
           value == "rs03" || value == "rs04";
}

static bool is_integer_token(const char *value)
{
    if (value == nullptr || *value == '\0')
        return false;

    char *end = nullptr;
    std::strtol(value, &end, 10);
    return end != value && *end == '\0';
}

int main(int argc, char *argv[])
{    std::ofstream file("motor_log.csv");

    if (!file.is_open()) {
        std::cerr << "Failed to open file!" << std::endl;
        return 1;
    }
    file << "timestamp_ms,"
     << "motor_id,"
     << "raw,"
     << "target_deg,"
     << "target_vel_deg_s,"
     << "actual_deg,"
     << "error_deg,"
     << "vel_deg_s,"
     << "kp,"
     << "kd,"
     << "torque_ff,"
     << "actual_torque,"
     << "loop_dt_us,"
     << "observed_hz"
     << "\n";

    int frequency_hz = 50;
    int arg_index = 1;
    int r_seconds = 10;
    int w_seconds = 1;
    int t_seconds = 10;
    enum OverrunPolicy { OP_WARN = 0, OP_CATCHUP = 1, OP_SKIP = 2 };
    OverrunPolicy overrun_policy = OP_WARN;

    // Parse leading --flags: --hz N, --r-sec N, --w-sec N, --t-sec N, --overrun {warn,catchup,skip}
    while (arg_index < argc && std::string(argv[arg_index]).rfind("--", 0) == 0)
    {
        std::string flag = argv[arg_index];
        if (flag == "--hz" && arg_index + 1 < argc)
        {
            frequency_hz = std::max(1, std::atoi(argv[arg_index + 1]));
            arg_index += 2;
        }
        else if (flag == "--r-sec" && arg_index + 1 < argc)
        {
            r_seconds = std::max(0, std::atoi(argv[arg_index + 1]));
            arg_index += 2;
        }
        else if (flag == "--w-sec" && arg_index + 1 < argc)
        {
            w_seconds = std::max(0, std::atoi(argv[arg_index + 1]));
            arg_index += 2;
        }
        else if (flag == "--t-sec" && arg_index + 1 < argc)
        {
            t_seconds = std::max(0, std::atoi(argv[arg_index + 1]));
            arg_index += 2;
        }
        else if (flag == "--overrun" && arg_index + 1 < argc)
        {
            std::string val = argv[arg_index + 1];
            if (val == "warn") overrun_policy = OP_WARN;
            else if (val == "catchup") overrun_policy = OP_CATCHUP;
            else if (val == "skip") overrun_policy = OP_SKIP;
            arg_index += 2;
        }
        else
        {
            break;
        }
    }

    if (argc - arg_index < 5)
    {
        std::cerr << "Usage: sudo ./multi_motor_functionality [--hz N] <z|zp|r|w|t> <target_deg> <kp> <kd> [<id> <type> [<torque_nm> [<kp> <kd>]] ...]\n"
                  << "       sudo ./multi_motor_functionality [--hz N] s <hold_ms> <cycles> <step_count> [<angle_deg> <kp> <kd> <torque_nm> <velocity_deg_s>]... [<id> <type> ...]\n"
                  << "  z   — zero all listed motors\n"
                  << "  zp  — zero only the motor whose id == target_deg\n"
                  << "  r   — passive read all (zero torque)\n"
                  << "  w   — move+read all to target_deg\n"
                  << "  s   — move+read all through step list, holding each target\n"
                  << "  torque_nm, kp, kd (optional per motor) — defaults are command kp/kd and zero torque\n"
                  << "Example: sudo ./multi_motor_functionality --hz 50 w 90 1.0 0.5 11 rs03 0.0 1.0 0.5 12 rs02 5.0 1.5 0.8\n"
                  << "Example: sudo ./multi_motor_functionality --hz 100 s 1000 1 2 0 1.0 0.5 0.0 0.0 90 1.2 0.6 0.0 20.0 11 rs03\n";
        return -1;
    }

    std::string cmd = argv[arg_index];
    double target_deg = 0.0;
    double target_rad = 0.0;
    double kp = 1.0;
    double kd = 0.5;
    int motor_arg_start = arg_index + 4;
    int hold_ms = 1000;
    int cycles = 1;
    bool sequence_has_step_controls = false;
    std::vector<SequenceStep> sequence_steps;

    auto is_motor_start_at = [&](int index) {
        return index + 1 < argc &&
               is_integer_token(argv[index]) &&
               is_motor_type(argv[index + 1]);
    };

    auto arg = [&](int relative) -> const char* {
        int index = arg_index + relative;
        return index < argc ? argv[index] : nullptr;
    };

    if (cmd == "s")
    {
        if (argc - arg_index < 5)
        {
            std::cerr << "Usage: sudo ./multi_motor_functionality [--hz N] s <hold_ms> <cycles> <step_count> [<angle_deg> <kp> <kd> <torque_nm> <velocity_deg_s>]... [<id> <type> ...]\n";
            return -1;
        }

        int step_count = std::max(0, std::atoi(arg(3)));
        int new_format_motor_arg_start = arg_index + 4 + step_count * 5;

        if (step_count > 0 && is_motor_start_at(new_format_motor_arg_start))
        {
            hold_ms = std::max(20, std::atoi(arg(1)));
            cycles = std::max(1, std::atoi(arg(2)));
            motor_arg_start = new_format_motor_arg_start;
            sequence_has_step_controls = true;

            for (int i = 0; i < step_count; i++)
            {
                int base = 4 + i * 5;
                SequenceStep step;
                step.angle_deg = std::atof(arg(base));
                step.kp = std::atof(arg(base + 1));
                step.kd = std::atof(arg(base + 2));
                step.torque_ff = std::atof(arg(base + 3));
                step.velocity_deg_s = std::atof(arg(base + 4));
                sequence_steps.push_back(step);
            }

            kp = sequence_steps.front().kp;
            kd = sequence_steps.front().kd;
        }
        else
        {
            kp = std::atof(arg(1));
            kd = std::atof(arg(2));
            hold_ms = std::max(20, std::atoi(arg(3)));
            cycles = std::max(1, std::atoi(arg(4)));
            int angle_count = std::max(0, std::atoi(arg(5)));
            motor_arg_start = arg_index + 6 + angle_count;

            if (angle_count <= 0 || !is_motor_start_at(motor_arg_start))
            {
                std::cerr << "Sequence command needs at least one step and one motor.\n";
                return -1;
            }

            for (int i = 0; i < angle_count; i++)
            {
                SequenceStep step;
                step.angle_deg = std::atof(arg(6 + i));
                step.kp = kp;
                step.kd = kd;
                sequence_steps.push_back(step);
            }
        }
    }
    else
    {
        target_deg = std::atof(arg(1));
        target_rad = target_deg * M_PI / 180.0;
        kp = std::atof(arg(2));
        kd = std::atof(arg(3));
    }

    std::vector<Motor> motors;
    // Parse motors: [<id> <type> [<torque> [<kp> <kd>]]] ...
    for (int i = motor_arg_start; i + 1 < argc;)
    {
        Motor m;
        m.id = std::atoi(argv[i]);
        m.type = argv[i + 1];
        m.target_rad = target_rad;
        m.kp = kp;
        m.kd = kd;

        i += 2;

        if (i < argc && !is_motor_start_at(i))
        {
            m.torque_ff = std::atof(argv[i]);
            i++;
        }
        if (i < argc && !is_motor_start_at(i))
        {
            m.kp = std::atof(argv[i]);
            i++;
        }
        if (i < argc && !is_motor_start_at(i))
        {
            m.kd = std::atof(argv[i]);
            i++;
        }
        motors.push_back(m);
    }

    CanInterface can;
    if (!can.init("can0") || !can.is_ready())
    {
        std::cerr << "Failed to initialize CAN interface\n";
        return -1;
    }

    // ---- zero all -------------------------------------------------------
    if (cmd == "z")
    {
        for (auto &m : motors)
        {
            std::cout << "Zeroing motor " << m.id << " (" << m.type << ")...\n";
            set_zero_position(can, m.id);
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        struct can_frame tmp;
        while (can.read_frame(&tmp, 5))
        {
        }
        std::cout << "Done. All motors zeroed.\n";
        return 0;
    }

    // ---- zero particular ------------------------------------------------
    if (cmd == "zp")
    {
        int target_id = (int)target_deg; // reuse target_deg slot as motor id
        bool found = false;
        for (auto &m : motors)
        {
            if (m.id == target_id)
            {
                std::cout << "Zeroing motor " << m.id << " (" << m.type << ")...\n";
                set_zero_position(can, m.id);
                std::this_thread::sleep_for(std::chrono::milliseconds(200));
                found = true;
                break;
            }
        }
        if (!found)
            std::cerr << "Motor id " << target_id << " not found in list.\n";
        struct can_frame tmp;
        while (can.read_frame(&tmp, 5))
        {
        }
        return 0;
    }

    // ---- enable + MIT mode for all --------------------------------------
    for (auto &m : motors)
        send_enable(can, m.id);
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    for (auto &m : motors)
        send_mode(can, m.id, ControlMode::MIT_MODE);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    enable_realtime();
    auto start_time = std::chrono::steady_clock::now();
    double loop_period_ms = 1000.0 / frequency_hz;
    auto loop_period = std::chrono::duration<double, std::milli>(loop_period_ms);

    // ---- read all (passive, zero torque) --------------------------------
    if (cmd == "r")
    {
        LoggerThread logger(file, true);
        auto stop_time = std::chrono::steady_clock::now() + std::chrono::seconds(r_seconds);
        auto next_time = std::chrono::steady_clock::now();
        auto last_cycle_time = std::chrono::steady_clock::now();
        bool first_cycle = true;
        while (std::chrono::steady_clock::now() < stop_time)
        {
            auto loop_start = std::chrono::steady_clock::now();
            double dt_us = 0.0;
            double observed_hz = 0.0;
            if (!first_cycle)
            {
                dt_us = std::chrono::duration<double, std::micro>(loop_start - last_cycle_time).count();
                observed_hz = dt_us > 0.0 ? 1e6 / dt_us : 0.0;
            }
            first_cycle = false;
            last_cycle_time = loop_start;
            for (auto &m : motors)
            {
                uint8_t data[8];
                pack_u16_be(&data[0], 0x7FFF);
                pack_u16_be(&data[2], 0x7FFF);
                pack_u16_be(&data[4], 0x0000); // kp=0
                pack_u16_be(&data[6], 0x0000); // kd=0
                uint32_t ctrl_id = (CommType::OPERATION_CONTROL << 24) | (0x7FFF << 8) | m.id;
                can.write_frame(ctrl_id, data, 8);
            }
            collect_status(can, motors);
            
            auto now_stamp = std::chrono::steady_clock::now();
            auto timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now_stamp - start_time).count();

            // Enqueue logs instead of blocking on I/O
            for (auto &m : motors)
            {
                std::ostringstream oss;
                oss << "motor=" << m.id
                    << "  raw=" << m.pos_raw
                    << "  pos=" << m.pos * 180.0 / M_PI << " deg"
                    << "  vel=" << m.filtered_vel * 180.0 / M_PI << " deg/s"
                    << "  torque=" << m.torque << " Nm\n";
                logger.enqueue_console(oss.str());

                LogEntry entry;
                entry.timestamp_ms = timestamp_ms;
                entry.motor_id = m.id;
                entry.pos_raw = m.pos_raw;
                entry.target_deg = 0.0;
                entry.target_vel_deg_s = 0.0;
                entry.actual_deg = m.pos * 180.0 / M_PI;
                entry.error_deg = -entry.actual_deg;
                entry.vel_deg_s = m.filtered_vel * 180.0 / M_PI;
                entry.kp = 0.0;
                entry.kd = 0.0;
                entry.torque_ff = 0.0;
                entry.actual_torque = m.torque;
                entry.loop_dt_us = dt_us;
                entry.observed_hz = observed_hz;
                logger.enqueue_log(entry);
            }

            next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
            auto now = std::chrono::steady_clock::now();
            if (now < next_time)
                std::this_thread::sleep_until(next_time);
            else
            {
                if (overrun_policy == OP_WARN)
                {
                    std::cerr << "Warning: loop overrun in 'r' mode\n";
                    next_time = std::chrono::steady_clock::now();
                }
                else if (overrun_policy == OP_SKIP)
                {
                    next_time = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
                else if (overrun_policy == OP_CATCHUP)
                {
                    while (next_time <= now)
                        next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
            }
        }
        logger.wait_for_flush();
        for (auto &m : motors)
            disable(can, m.id);
        return 0;
    }

    // ---- move + read all ------------------------------------------------
    if (cmd == "w")
    {
        LoggerThread logger(file, true);
        auto stop_time = std::chrono::steady_clock::now() + std::chrono::seconds(w_seconds);
        auto next_time = std::chrono::steady_clock::now();
        auto last_cycle_time = std::chrono::steady_clock::now();
        bool first_cycle = true;
        while (std::chrono::steady_clock::now() < stop_time)
        {
            auto loop_start = std::chrono::steady_clock::now();
            double dt_us = 0.0;
            double observed_hz = 0.0;
            if (!first_cycle)
            {
                dt_us = std::chrono::duration<double, std::micro>(loop_start - last_cycle_time).count();
                observed_hz = dt_us > 0.0 ? 1e6 / dt_us : 0.0;
            }
            first_cycle = false;
            last_cycle_time = loop_start;
            for (auto &m : motors)
                send_position(can, m.id, m.target_rad, m.kp, m.kd, m.type, m.torque_ff);
            collect_status(can, motors);
            auto now_stamp = std::chrono::steady_clock::now();

            for (auto &m : motors)
            {
                double actual_deg = m.pos * 180.0 / M_PI;
                double vel_deg_s = m.filtered_vel * 180.0 / M_PI;
                double motor_target_deg = m.target_rad * 180.0 / M_PI;
                double error_deg = motor_target_deg - actual_deg;
                
                std::ostringstream oss;
                oss << "motor=" << m.id
                    << "  raw=" << m.pos_raw
                    << "  pos=" << actual_deg << " deg"
                    << "  vel=" << vel_deg_s << " deg/s"
                    << "  target=" << motor_target_deg << " deg"
                    << "  torque=" << m.torque << " Nm\n";
                logger.enqueue_console(oss.str());

                auto timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now_stamp - start_time).count();
                LogEntry entry;
                entry.timestamp_ms = timestamp_ms;
                entry.motor_id = m.id;
                entry.pos_raw = m.pos_raw;
                entry.target_deg = motor_target_deg;
                entry.target_vel_deg_s = 0.0;
                entry.actual_deg = actual_deg;
                entry.error_deg = error_deg;
                entry.vel_deg_s = vel_deg_s;
                entry.kp = m.kp;
                entry.kd = m.kd;
                entry.torque_ff = m.torque_ff;
                entry.actual_torque = m.torque;
                entry.loop_dt_us = dt_us;
                entry.observed_hz = observed_hz;
                logger.enqueue_log(entry);
            }

            next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
            auto now = std::chrono::steady_clock::now();
            if (now < next_time)
                std::this_thread::sleep_until(next_time);
            else
            {
                if (overrun_policy == OP_WARN)
                {
                    std::cerr << "Warning: loop overrun in 'w' mode\n";
                    next_time = std::chrono::steady_clock::now();
                }
                else if (overrun_policy == OP_SKIP)
                {
                    next_time = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
                else if (overrun_policy == OP_CATCHUP)
                {
                    while (next_time <= now)
                        next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
            }
        }
        logger.wait_for_flush();
        std::cout << "CSV logging completed." << std::endl;
        for (auto &m : motors)
            disable(can, m.id);
        return 0;
    }

    // ---- angle sequence + hold -----------------------------------------
    if (cmd == "s")
    {
        RealtimeGnuplot plotter(motors);
        LoggerThread logger(file, true, &plotter);
        int plot_iter = 0;

        for (int cycle = 0; cycle < cycles; cycle++)
        {
            for (const auto &step : sequence_steps)
            {
                double angle_rad = step.angle_deg * M_PI / 180.0;
                double velocity_rad_s = step.velocity_deg_s * M_PI / 180.0;
                for (auto &m : motors)
                    m.target_rad = angle_rad;

                std::ostringstream header;
                header << "Holding target " << step.angle_deg << " deg";
                if (sequence_has_step_controls)
                    header << "  kp=" << step.kp
                           << "  kd=" << step.kd
                           << "  torque=" << step.torque_ff << " Nm"
                           << "  velocity=" << step.velocity_deg_s << " deg/s";
                header << "  cycle=" << (cycle + 1) << "/" << cycles << "\n";
                logger.enqueue_console(header.str());

                auto hold_end = std::chrono::steady_clock::now() + std::chrono::milliseconds(hold_ms);
                auto next_time = std::chrono::steady_clock::now();
                auto last_cycle_time = std::chrono::steady_clock::now();
                bool first_cycle = true;
                while (std::chrono::steady_clock::now() < hold_end)
                {
                    auto loop_start = std::chrono::steady_clock::now();
                    double dt_us = 0.0;
                    double observed_hz = 0.0;
                    if (!first_cycle)
                    {
                        dt_us = std::chrono::duration<double, std::micro>(loop_start - last_cycle_time).count();
                        observed_hz = dt_us > 0.0 ? 1e6 / dt_us : 0.0;
                    }
                    first_cycle = false;
                    last_cycle_time = loop_start;
                    for (auto &m : motors)
                    {
                        double command_kp = sequence_has_step_controls ? step.kp : m.kp;
                        double command_kd = sequence_has_step_controls ? step.kd : m.kd;
                        double command_torque = sequence_has_step_controls ? step.torque_ff : m.torque_ff;
                        double command_velocity = sequence_has_step_controls ? velocity_rad_s : 0.0;
                        send_position(can, m.id, m.target_rad, command_kp, command_kd,
                                      m.type, command_torque, command_velocity);
                    }

                    collect_status(can, motors);
                    auto now_stamp = std::chrono::steady_clock::now();
                    auto timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now_stamp - start_time).count();

                    for (auto &m : motors)
                    {
                        double actual_deg = m.pos * 180.0 / M_PI;
                        double vel_deg_s = m.filtered_vel * 180.0 / M_PI;
                        double error_deg = step.angle_deg - actual_deg;
                        double command_kp = sequence_has_step_controls ? step.kp : m.kp;
                        double command_kd = sequence_has_step_controls ? step.kd : m.kd;
                        double command_torque = sequence_has_step_controls ? step.torque_ff : m.torque_ff;
                        double command_velocity_deg_s = sequence_has_step_controls ? step.velocity_deg_s : 0.0;

                        std::ostringstream oss;
                        oss << "motor=" << m.id
                            << "  raw=" << m.pos_raw
                            << "  pos=" << actual_deg << " deg"
                            << "  vel=" << vel_deg_s << " deg/s"
                            << "  target=" << step.angle_deg << " deg"
                            << "  torque=" << m.torque << " Nm\n";
                        logger.enqueue_console(oss.str());

                        LogEntry entry;
                        entry.timestamp_ms = timestamp_ms;
                        entry.motor_id = m.id;
                        entry.pos_raw = m.pos_raw;
                        entry.target_deg = step.angle_deg;
                        entry.target_vel_deg_s = command_velocity_deg_s;
                        entry.actual_deg = actual_deg;
                        entry.error_deg = error_deg;
                        entry.vel_deg_s = vel_deg_s;
                        entry.kp = command_kp;
                        entry.kd = command_kd;
                        entry.torque_ff = command_torque;
                        entry.actual_torque = m.torque;
                        entry.loop_dt_us = dt_us;
                        entry.observed_hz = observed_hz;
                        logger.enqueue_log(entry);
                    }

                    logger.set_plotter_redraw(plot_iter++, 5);
                    next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                    auto now = std::chrono::steady_clock::now();
                    if (now < next_time)
                        std::this_thread::sleep_until(next_time);
                    else
                    {
                        if (overrun_policy == OP_WARN)
                        {
                            std::cerr << "Warning: loop overrun in 's' sequence hold\n";
                            next_time = std::chrono::steady_clock::now();
                        }
                        else if (overrun_policy == OP_SKIP)
                        {
                            next_time = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                        }
                        else if (overrun_policy == OP_CATCHUP)
                        {
                            while (next_time <= now)
                                next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                        }
                    }
                }
            }
        }

        logger.wait_for_flush();
        if (plotter.ready())
        {
            plotter.redraw_all();
        }

        std::cout << "CSV logging completed." << std::endl;
        for (auto &m : motors)
            disable(can, m.id);
        return 0;
    }

    // ---- torque control + read all (pure torque, zero position/gains) ---
    if (cmd == "t")
    {
        LoggerThread logger(file, true);
        auto stop_time = std::chrono::steady_clock::now() + std::chrono::seconds(t_seconds);
        auto next_time = std::chrono::steady_clock::now();
        auto last_cycle_time = std::chrono::steady_clock::now();
        bool first_cycle = true;
        while (std::chrono::steady_clock::now() < stop_time)
        {
            auto loop_start = std::chrono::steady_clock::now();
            double dt_us = 0.0;
            double observed_hz = 0.0;
            if (!first_cycle)
            {
                dt_us = std::chrono::duration<double, std::micro>(loop_start - last_cycle_time).count();
                observed_hz = dt_us > 0.0 ? 1e6 / dt_us : 0.0;
            }
            first_cycle = false;
            last_cycle_time = loop_start;
            for (auto &m : motors)
                send_position(can, m.id, 0.0, 0.0, 0.0, m.type, m.torque_ff);
            collect_status(can, motors);

            auto now_stamp = std::chrono::steady_clock::now();
            for (auto &m : motors)
            {
                std::ostringstream oss;
                oss << "motor=" << m.id
                    << "  raw=" << m.pos_raw
                    << "  pos=" << m.pos * 180.0 / M_PI << " deg"
                    << "  vel=" << m.filtered_vel * 180.0 / M_PI << " deg/s"
                    << "  torque=" << m.torque << " Nm\n";
                logger.enqueue_console(oss.str());

                auto timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now_stamp - start_time).count();
                LogEntry entry;
                entry.timestamp_ms = timestamp_ms;
                entry.motor_id = m.id;
                entry.pos_raw = m.pos_raw;
                entry.target_deg = 0.0;
                entry.target_vel_deg_s = 0.0;
                entry.actual_deg = m.pos * 180.0 / M_PI;
                entry.error_deg = -entry.actual_deg;
                entry.vel_deg_s = m.filtered_vel * 180.0 / M_PI;
                entry.kp = 0.0;
                entry.kd = 0.0;
                entry.torque_ff = m.torque_ff;
                entry.actual_torque = m.torque;
                entry.loop_dt_us = dt_us;
                entry.observed_hz = observed_hz;
                logger.enqueue_log(entry);
            }

            next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
            auto now = std::chrono::steady_clock::now();
            if (now < next_time)
                std::this_thread::sleep_until(next_time);
            else
            {
                if (overrun_policy == OP_WARN)
                {
                    std::cerr << "Warning: loop overrun in 't' mode\n";
                    next_time = std::chrono::steady_clock::now();
                }
                else if (overrun_policy == OP_SKIP)
                {
                    next_time = std::chrono::steady_clock::now() + std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
                else if (overrun_policy == OP_CATCHUP)
                {
                    while (next_time <= now)
                        next_time += std::chrono::duration_cast<std::chrono::steady_clock::duration>(loop_period);
                }
            }
        }
        logger.wait_for_flush();
        for (auto &m : motors)
            disable(can, m.id);
        return 0;
    }

    std::cerr << "Unknown command: " << cmd << "\n";
    return -1;
}
